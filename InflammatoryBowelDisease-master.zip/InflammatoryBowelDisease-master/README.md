# InflammatoryBowelDisease
The DATASET came from this paper: Classification of Paediatric Inflammatory Bowel Disease using Machine Learning
https://www.nature.com/articles/s41598-017-02606-2
https://static-content.springer.com/esm/art%3A10.1038%2Fs41598-017-02606-2/MediaObjects/41598_2017_2606_MOESM1_ESM.xls
